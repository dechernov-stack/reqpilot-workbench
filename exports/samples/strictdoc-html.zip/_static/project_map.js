// map of the project for the stable_uri forwarder
window.StrictDoc = window.StrictDoc || {};
window.StrictDoc.project = window.StrictDoc.project || {};
window.StrictDoc.project.map = {
 "requirements/01_stakeholder.html": [


  {"MID":"mid_doc_stakeholder","_LINK":"None-Требования-заинтересованных-сторон" },

  {"MID":"mid_req_stk_001","UID":"STK-001","_LINK":"STK-001" },

  {"MID":"mid_req_stk_002","UID":"STK-002","_LINK":"STK-002" },

  {"MID":"mid_req_stk_003","UID":"STK-003","_LINK":"STK-003" }, ],
 "requirements/02_system.html": [


  {"MID":"mid_doc_system","_LINK":"None-Системные-требования" },

  {"MID":"mid_req_sys_001","UID":"SYS-001","_LINK":"SYS-001" },

  {"MID":"mid_req_sys_002","UID":"SYS-002","_LINK":"SYS-002" },

  {"MID":"mid_req_sys_003","UID":"SYS-003","_LINK":"SYS-003" },

  {"MID":"mid_req_sys_004","UID":"SYS-004","_LINK":"SYS-004" },

  {"MID":"mid_req_sys_005","UID":"SYS-005","_LINK":"SYS-005" },

  {"MID":"mid_req_sys_006","UID":"SYS-006","_LINK":"SYS-006" }, ],
 "requirements/03_software_interface.html": [


  {"MID":"mid_doc_software_interface","_LINK":"None-Программные-и-интерфейсные-требования" },

  {"MID":"mid_req_if_001","UID":"IF-001","_LINK":"IF-001" },

  {"MID":"mid_req_if_002","UID":"IF-002","_LINK":"IF-002" },

  {"MID":"mid_req_sw_001","UID":"SW-001","_LINK":"SW-001" },

  {"MID":"mid_req_sw_002","UID":"SW-002","_LINK":"SW-002" },

  {"MID":"mid_req_sw_003","UID":"SW-003","_LINK":"SW-003" },

  {"MID":"mid_req_sw_004","UID":"SW-004","_LINK":"SW-004" }, ],
 "requirements/04_safety.html": [


  {"MID":"mid_doc_safety","_LINK":"None-Требования-безопасности" },

  {"MID":"mid_req_saf_001","UID":"SAF-001","_LINK":"SAF-001" },

  {"MID":"mid_req_saf_002","UID":"SAF-002","_LINK":"SAF-002" }, ],
 "requirements/05_tests.html": [


  {"MID":"mid_doc_verification","_LINK":"None-Проверка-и-испытания" },

  {"MID":"mid_req_tst_001","UID":"TST-001","_LINK":"TST-001" },

  {"MID":"mid_req_tst_002","UID":"TST-002","_LINK":"TST-002" },

  {"MID":"mid_req_tst_003","UID":"TST-003","_LINK":"TST-003" },

  {"MID":"mid_req_tst_004","UID":"TST-004","_LINK":"TST-004" },

  {"MID":"mid_req_tst_005","UID":"TST-005","_LINK":"TST-005" },

  {"MID":"mid_req_tst_006","UID":"TST-006","_LINK":"TST-006" },

  {"MID":"mid_req_tst_007","UID":"TST-007","_LINK":"TST-007" }, ],
};